# perfectNorthAlexaSnowReport
Retrieves and outputs the snow report from Perfect North
